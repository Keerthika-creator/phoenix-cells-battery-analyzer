import streamlit as st
import joblib

# Load trained model
model = joblib.load("battery_model.pkl")

# App UI
st.title("🔋 Phoenix Cells – Battery Life Analyzer")

voltage = st.number_input("Voltage (V)", min_value=0.0, step=0.1)
temperature = st.number_input("Temperature (°C)", min_value=0.0, step=0.5)
capacity = st.number_input("Capacity (mAh)", min_value=0.0, step=50.0)

if st.button("Analyze Battery"):
    result = model.predict([[voltage, temperature, capacity]])
    st.success(f"Predicted Battery Health: **{result[0]}**")
