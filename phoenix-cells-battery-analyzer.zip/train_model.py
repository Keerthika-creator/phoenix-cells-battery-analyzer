import pandas as pd
from sklearn.tree import DecisionTreeClassifier
import joblib

# Load data
df = pd.read_csv("battery_data.csv")
X = df[['Voltage', 'Temperature', 'Capacity']]
y = df['BatteryHealth']

# Train model
model = DecisionTreeClassifier()
model.fit(X, y)

# Save model
joblib.dump(model, 'battery_model.pkl')
print("Model trained and saved as battery_model.pkl")
